import React from 'react'
import '../App.scss'

const PostD = () => {
  return (
   <>
      <div className='create_container'>
        <ul>
          <h2 className='create_h2'>Manage posts</h2>
          <span className='create_span'></span>
          <li>

          </li>
        </ul>
      </div>
   </>
  )
}

export default PostD